var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
  
var db = mongo.connect("mongodb://localhost:27017/screentest", function(err, response){  
   if(err){ console.log( err); }  
   else{ console.log('Connected to ' + db, ' + ', response); }  
});  
  
   
var app = express()  
app.use(bodyParser());  
app.use(bodyParser.json({limit:'5mb'}));   
app.use(bodyParser.urlencoded({extended:true}));  
   
  
app.use(function (req, res, next) {        
     res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');    
     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');    
     res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');      
     res.setHeader('Access-Control-Allow-Credentials', true);       
     next();  
 });  
  
 var Schema = mongo.Schema;  
  
var UsersSchema = new Schema({      
 firstname: { type: String   },       
 lastname: { type: String   },   
},{ versionKey: false });  

var ProductSchema = new Schema({      
    product: { type: String   },       
    price: { type: Number   },   
   },{ versionKey: false });  
   
var orderSchema = new Schema({      
    user: { type: String   },
    product: { type: String   },       
    price: { type: Number   },   
    quantity: { type: Number   },
    total: { type: Number   },
    date: { type: Date   },   
   },{ versionKey: false });  
      
  
var model = mongo.model('user', UsersSchema, 'user'); 

var prdModel = mongo.model('product', ProductSchema, 'product'); 

var orderModel = mongo.model('order', orderSchema, 'order'); 
  
app.post("/api/SaveOrder",function(req,res){   
    var mod = new orderModel(req.body);  
       mod.save(function(err,data){  
         if(err){  
            res.send(err);                
         }  
         else{        
             res.send({data:"Record has been Inserted..!!"});  
         }  
    });  
    
   })  

app.post("/api/SaveUser",function(req,res){   
 var mod = new model(req.body);  
    mod.save(function(err,data){  
      if(err){  
         res.send(err);                
      }  
      else{        
          res.send({data:"Record has been Inserted..!!"});  
      }  
 });  
 
})  

app.post("/api/SaveProduct",function(req,res){   
    var mod = new prdModel(req.body);  
       mod.save(function(err,data){  
         if(err){  
            res.send(err);                
         }  
         else{        
             res.send({data:"Record has been Inserted..!!"});  
         }  
    });  
    
   })  
  
 app.post("/api/deleteOrder",function(req,res){      
    orderModel.remove({ _id: req.body.id }, function(err) {    
     if(err){    
         res.send(err);    
     }    
     else{      
            res.send({data:"Record has been Deleted..!!"});               
        }    
 });    
   })  
  
  
  
 app.get("/api/getUser",function(req,res){  
    model.find({},function(err,data){  
              if(err){  
                  res.send(err);  
              }  
              else{                
                  res.send(data);  
                  }  
          });  
  })  
  
  app.get("/api/getProduct",function(req,res){  
    prdModel.find({},function(err,data){  
              if(err){  
                  res.send(err);  
              }  
              else{                
                  res.send(data);  
                  }  
          });  
  }) 

  app.get("/api/getOrder",function(req,res){  
    orderModel.find({},function(err,data){  
              if(err){  
                  res.send(err);  
              }  
              else{                
                  res.send(data);  
                  }  
          });  
  })  
  
app.listen(8080, function () {  
    
 console.log('Example app listening on port 8080!')  
})  