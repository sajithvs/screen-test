export class OrderDetails {
    user: string;
    product: string;
    price: number;
    quantity:number;
    total: number;
    date: Date;
    
}

