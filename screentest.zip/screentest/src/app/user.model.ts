export class UserDetails {
    firstname: string;
    lastname: string;
}

