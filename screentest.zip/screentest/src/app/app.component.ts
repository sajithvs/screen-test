import { Component } from '@angular/core';
import { DbserviceService } from './dbservice.service';
import { UserDetails } from './user.model';
import { ProductDetails } from './product.model';
import { OrderDetails } from './order.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app';
 
 userDetails : UserDetails = new UserDetails();
 productDetails : ProductDetails = new ProductDetails();
 orderDetails : Object = new Object();
 userDetailList : string[] = [];
 productDetailsList : ProductDetails[] = [];
 orderDetailsList : OrderDetails[] = [];
 orderDetailsObj : OrderDetails = new OrderDetails();
 constructor(private dbService : DbserviceService){}
 

 ngOnInit(){
  this.getAllUser(); 
  this.getAllproduct();  
  this.getAllOrder(); 
 }

 getAllOrder(): void {
  this.orderDetailsList = []
  this.dbService.getAllOrder().subscribe(value => {
   this.orderDetailsList = value;
   console.log("this.orderDetailsList", this.orderDetailsList)
  },error => {
    console.log("Error while calling get all service")
    alert("Error while calling get all service. Error : "+ error)
  });
}
deleteOrder(id):void {  
  this.dbService.deleteOrder(id).subscribe(value => {
    this.getAllOrder(); 
  },error => {
   
  });
  }

  editOrder(orderDetailObj : OrderDetails):void {  
    console.log("orderDetailObj", orderDetailObj)  
    this.orderDetailsObj = orderDetailObj;
    this.orderDetails["user"] = this.orderDetailsObj.user;
    this.orderDetails["quantity"] = this.orderDetailsObj.quantity;
    for(var i = 0 ; i < this.productDetailsList.length ; i++){
      if(this.productDetailsList[i].product == this.orderDetailsObj.product){
        this.orderDetails["product"] = this.productDetailsList[i]
      }
    }
    
  }

 getAllUser(): void {
  this.userDetailList = []
  this.dbService.getAllUser().subscribe(value => {
    console.log(value)
   for(var i = 0 ; i < value.length ; i++){
    this.userDetailList.push(value[i].firstname+ ' ' + value[i].lastname)
   }
  },error => {
    console.log("Error while calling get all service")
    alert("Error while calling get all service. Error : "+ error)
  });
}

getAllproduct(): void {
  this.productDetailsList = []
  this.dbService.getAllProduct().subscribe(value => {
  console.log(value)
  this.productDetailsList = value;
  console.log("product", this.productDetailsList)
  },error => {
    console.log("Error while calling get all service")
    alert("Error while calling get all service. Error : "+ error)
  });
}


 createProduct(): void {
   this.dbService.createProduct(this.productDetails).subscribe(value => {
    console.log(value)  
   
      console.log("product inserted successfully")
      this.productDetails = new ProductDetails();
      this.getAllproduct();  
      alert("product Inserted Successfully")
  
  },error => {
    console.log("Error while calling create product service")
    alert("Error while calling create product service. Error : "+ error)
  });
 }

 createOrder(): void {
  this.orderDetailsObj.user = this.orderDetails["user"];
  let product = this.orderDetails["product"];
  this.orderDetailsObj.product = product["product"];
  this.orderDetailsObj.price = product["price"];
  this.orderDetailsObj.quantity = this.orderDetails["quantity"];
  this.orderDetailsObj.total = this.orderDetailsObj.price * this.orderDetailsObj.quantity;
  this.orderDetailsObj.date = new Date();
  console.log(this.orderDetailsObj)
  this.dbService.createOrder(this.orderDetailsObj).subscribe(value => {
      console.log("product inserted successfully")
      this.productDetails = new ProductDetails();
      this.getAllOrder(); 
      alert("product Inserted Successfully")
   
  },error => {
    console.log("Error while calling create product service")
    alert("Error while calling create product service. Error : "+ error)
  });
 }

 createUser(validationFlag: boolean): void {
  if(validationFlag){
    return
  }
  console.log("User Details ", this.userDetails);
  this.dbService.createUser(this.userDetails).subscribe(value => {
    console.log(value)  
    this.getAllUser(); 
    this.userDetails = new UserDetails();
  },error => {
    console.log("Error while calling create user service")
    alert("Error while calling create user service. Error : "+ error)
  });
}




}