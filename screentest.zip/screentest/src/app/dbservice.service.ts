
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserDetails } from './user.model';
import { ProductDetails } from './product.model';
import { OrderDetails } from './order.model';

@Injectable({
  providedIn: 'root'
})
export class DbserviceService {

  endPoint = "http://localhost:8080/";
  httpHeader = {
    headers : new HttpHeaders({
      'Content-Type':'application/json'
    })
  }
  
  constructor(private http: HttpClient) { }
  
  createUser(userDetails: UserDetails): Observable<any> {
    return this.http.post(this.endPoint+'api/SaveUser', JSON.stringify(userDetails), this.httpHeader).pipe(map(data=>data));
  }

  createProduct(productDetails: ProductDetails): Observable<any> {
    return this.http.post(this.endPoint+'api/SaveProduct', JSON.stringify(productDetails), this.httpHeader).pipe(map(data=>data));
  }

  createOrder(orderDetails: OrderDetails): Observable<any> {
    return this.http.post(this.endPoint+'api/SaveOrder', JSON.stringify(orderDetails), this.httpHeader).pipe(map(data=>data));
  }

  getAllUser(): Observable<any> {
    return this.http.get(this.endPoint+'api/getUser', this.httpHeader).pipe(map(data=>data));
  }

  getAllProduct(): Observable<any> {
    return this.http.get(this.endPoint+'api/getProduct', this.httpHeader).pipe(map(data=>data));
  }
  getAllOrder(): Observable<any> {
    return this.http.get(this.endPoint+'api/getOrder', this.httpHeader).pipe(map(data=>data));
  }
  deleteOrder(userId: string): Observable<any> {
    return this.http.post(this.endPoint+'api/deleteOrder', {'id': userId}, this.httpHeader).pipe(map(data=>data));
  }

  
 }
 
