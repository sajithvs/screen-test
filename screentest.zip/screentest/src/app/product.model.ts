export class ProductDetails {
    product: string;
    price: number;
}

